from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.backends import default_backend

def decrypt_chacha20_file(filepath, key):
    with open(filepath, 'rb') as f:
        nonce = f.read(16)
        ciphertext = f.read()
    algorithm = algorithms.ChaCha20(key, nonce)
    cipher = Cipher(algorithm, mode=None, backend=default_backend())
    decryptor = cipher.decryptor()
    decrypted = decryptor.update(ciphertext)
    with open(filepath.replace('.enc', '.dec.csv'), 'wb') as f:
        f.write(decrypted)
