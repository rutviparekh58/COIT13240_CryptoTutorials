# CSV Secure Sync Server
Run `server.py` to start the secure file upload server.
