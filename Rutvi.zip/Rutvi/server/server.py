from http.server import BaseHTTPRequestHandler, HTTPServer
import os

# ✅ Fixed imports
from utils.file_handler import save_file
from server.crypto.key_exchange import generate_shared_key
from server.crypto.decrypt_aes import decrypt_aes_file
from server.crypto.decrypt_chacha20 import decrypt_chacha20_file

UPLOAD_DIR = "uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

class SimpleHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == "/upload":
            content_length = int(self.headers['Content-Length'])
            filename = self.headers.get('X-Filename')
            cipher = self.headers.get('X-Cipher')

            if not filename or not cipher:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Missing filename or cipher")
                return

            file_data = self.rfile.read(content_length)
            filepath = save_file(UPLOAD_DIR, filename, file_data)

            shared_key = generate_shared_key()

            if cipher == "AES":
                decrypt_aes_file(filepath, shared_key)
            elif cipher == "ChaCha20":
                decrypt_chacha20_file(filepath, shared_key)
            else:
                self.send_response(400)
                self.end_headers()
                self.wfile.write(b"Unsupported cipher")
                return

            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"File uploaded and decrypted.")

def run(server_class=HTTPServer, handler_class=SimpleHandler, port=8080):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"Server running on port {port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()
