
# XOR operation example
a = int("010100", 2)
b = int("111001", 2)
xor_result = a ^ b
print("XOR Result:", format(xor_result, '06b'))  # Output: 101101
