
import hmac
import hashlib

key = b'secret'
message = b'Authenticate me'
h = hmac.new(key, message, hashlib.sha256)
print("HMAC:", h.hexdigest())
