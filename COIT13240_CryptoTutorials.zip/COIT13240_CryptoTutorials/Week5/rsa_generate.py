
from Crypto.Util import number

p = number.getPrime(8)
q = number.getPrime(8)
n = p * q
phi = (p - 1) * (q - 1)
e = 3
while number.GCD(e, phi) != 1:
    e += 2
d = pow(e, -1, phi)

print(f"Public Key: (e={e}, n={n})")
print(f"Private Key: (d={d}, n={n})")
