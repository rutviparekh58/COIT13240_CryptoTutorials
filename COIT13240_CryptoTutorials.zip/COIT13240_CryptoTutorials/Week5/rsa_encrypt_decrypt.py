
def encrypt(message, e, n):
    return pow(message, e, n)

def decrypt(ciphertext, d, n):
    return pow(ciphertext, d, n)

e, d, n = 7, 103, 187  # Example values
message = 123
cipher = encrypt(message, e, n)
decrypted = decrypt(cipher, d, n)

print("Ciphertext:", cipher)
print("Decrypted:", decrypted)
